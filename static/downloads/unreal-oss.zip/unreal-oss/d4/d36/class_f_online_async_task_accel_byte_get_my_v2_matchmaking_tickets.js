var class_f_online_async_task_accel_byte_get_my_v2_matchmaking_tickets =
[
    [ "GetTaskName", "d4/d36/class_f_online_async_task_accel_byte_get_my_v2_matchmaking_tickets.html#a83e199c73d895a41afed9c262c39cad8", null ],
    [ "Initialize", "d4/d36/class_f_online_async_task_accel_byte_get_my_v2_matchmaking_tickets.html#a4a93913c032da61c651524f523e1b53a", null ]
];