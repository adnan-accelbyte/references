var class_f_online_async_task_accel_byte_get_game_record =
[
    [ "GetTaskName", "d7/d0c/class_f_online_async_task_accel_byte_get_game_record.html#a87819a985180b7adfb554567e10ea66c", null ],
    [ "Initialize", "d7/d0c/class_f_online_async_task_accel_byte_get_game_record.html#a0fe4d2d21da38e0a4d7684821655bdea", null ]
];