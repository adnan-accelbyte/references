var class_f_online_async_task_accel_byte_promote_v2_party_leader =
[
    [ "GetTaskName", "d0/dda/class_f_online_async_task_accel_byte_promote_v2_party_leader.html#aad3239fc2f2130e717e54ea5ce512ba3", null ],
    [ "Initialize", "d0/dda/class_f_online_async_task_accel_byte_promote_v2_party_leader.html#a20e66b54d8d7023d45f052bf7c3f0468", null ]
];