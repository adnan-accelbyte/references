var class_f_online_async_task_accel_byte_get_wallet_info =
[
    [ "GetTaskName", "d0/d0b/class_f_online_async_task_accel_byte_get_wallet_info.html#ac6e9572660a547a34489fd76af6c7bba", null ],
    [ "Initialize", "d0/d0b/class_f_online_async_task_accel_byte_get_wallet_info.html#a84c9a61fdca02562ad0dc079bb9772bb", null ]
];