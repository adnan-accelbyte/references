var class_f_online_async_task_accel_byte_revoke_v2_party_code =
[
    [ "GetTaskName", "d2/d77/class_f_online_async_task_accel_byte_revoke_v2_party_code.html#ae0d7761f854b26fc884bdd4b3b4c2a19", null ],
    [ "Initialize", "d2/d77/class_f_online_async_task_accel_byte_revoke_v2_party_code.html#a23f9504ff40fea9b10a84001319b5dd7", null ]
];