var class_f_online_async_task_accel_byte_groups_query_group_info =
[
    [ "GetTaskName", "d2/dec/class_f_online_async_task_accel_byte_groups_query_group_info.html#a647f234528cfd4081ea846b6e46989db", null ],
    [ "Initialize", "d2/dec/class_f_online_async_task_accel_byte_groups_query_group_info.html#a6c399358285a7e83f88810c9b67860d2", null ]
];