var class_f_online_async_task_accel_byte_link_other_platform_id =
[
    [ "GetTaskName", "d2/d58/class_f_online_async_task_accel_byte_link_other_platform_id.html#a3c1051bdab2923c6f84b98dad91d6fa8", null ],
    [ "Initialize", "d2/d58/class_f_online_async_task_accel_byte_link_other_platform_id.html#af7141470e3453ec48f7c1f9125b95ba3", null ]
];