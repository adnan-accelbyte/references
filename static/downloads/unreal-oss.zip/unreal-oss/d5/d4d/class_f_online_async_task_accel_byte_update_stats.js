var class_f_online_async_task_accel_byte_update_stats =
[
    [ "GetTaskName", "d5/d4d/class_f_online_async_task_accel_byte_update_stats.html#ab2e2a877e19522a2e4b0afdad11e79b7", null ],
    [ "Initialize", "d5/d4d/class_f_online_async_task_accel_byte_update_stats.html#af441af1e5b326156d3f2e8ad18232be4", null ]
];