var class_f_online_async_task_accel_byte_promote_v1_party_leader =
[
    [ "GetTaskName", "d6/dca/class_f_online_async_task_accel_byte_promote_v1_party_leader.html#ac51cf75749a9dae9942b89eb17ddce5e", null ],
    [ "Initialize", "d6/dca/class_f_online_async_task_accel_byte_promote_v1_party_leader.html#a29f1008b4846d66a9918668589cf565a", null ]
];