var class_accel_byte_1_1_api_1_1_heart_beat =
[
    [ "AddSendData", "d0/ddb/class_accel_byte_1_1_api_1_1_heart_beat.html#a3c4a632c39cc4b3746a1aa9b5d1fa1ab", null ],
    [ "RemoveSendData", "d0/ddb/class_accel_byte_1_1_api_1_1_heart_beat.html#a346226d821cae00240b3c050f418e92e", null ],
    [ "SetHeartBeatCallback", "d0/ddb/class_accel_byte_1_1_api_1_1_heart_beat.html#a0e8df859801a89dc6ffc38b928092811", null ],
    [ "SetHeartBeatEnabled", "d0/ddb/class_accel_byte_1_1_api_1_1_heart_beat.html#a4477ebefa23b4948734029fae67ec24b", null ]
];