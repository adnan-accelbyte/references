var class_accel_byte_1_1_server_1_1_server_ecommerce =
[
    [ "CreditUserWallet", "d0/d9c/class_accel_byte_1_1_server_1_1_server_ecommerce.html#aa97fd177d1fe30d5be14583d9f3b8201", null ],
    [ "CreditUserWalletV2", "d0/d9c/class_accel_byte_1_1_server_1_1_server_ecommerce.html#afa7be55c3530ce9c6d7a52ef4d2724a3", null ],
    [ "FulfillUserItem", "d0/d9c/class_accel_byte_1_1_server_1_1_server_ecommerce.html#a034777b9b5eb17bffff880976412b00a", null ],
    [ "GetStoreList", "d0/d9c/class_accel_byte_1_1_server_1_1_server_ecommerce.html#a7d9032f4ce4615da8ce65f074dea0208", null ],
    [ "GetUserEntitlementById", "d0/d9c/class_accel_byte_1_1_server_1_1_server_ecommerce.html#aeaf5328a1cfaa54d25b96ca607b3d697", null ],
    [ "GrantUserEntitlement", "d0/d9c/class_accel_byte_1_1_server_1_1_server_ecommerce.html#a21b403ad66fdc0fcd5c9dd4b12a84315", null ],
    [ "QueryItemsByCriteria", "d0/d9c/class_accel_byte_1_1_server_1_1_server_ecommerce.html#abcbd9583e015fa929277eefde9bd6f4d", null ],
    [ "QueryItemsByCriteriaV2", "d0/d9c/class_accel_byte_1_1_server_1_1_server_ecommerce.html#a4349efb12d664a05b04f106f2efd4f60", null ]
];