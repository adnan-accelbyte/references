var namespace_core =
[
    [ "AccelByteWebsocketApi", "dc/dc1/class_core_1_1_accel_byte_websocket_api.html", "dc/dc1/class_core_1_1_accel_byte_websocket_api" ],
    [ "WsMessageFragmentProcessor", "d2/d2a/class_core_1_1_ws_message_fragment_processor.html", null ]
];