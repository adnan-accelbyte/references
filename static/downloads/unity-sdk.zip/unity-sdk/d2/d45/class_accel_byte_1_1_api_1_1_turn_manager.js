var class_accel_byte_1_1_api_1_1_turn_manager =
[
    [ "GetClosestTurnServer", "d2/d45/class_accel_byte_1_1_api_1_1_turn_manager.html#af99d100f2dee95a6f24fd4d8182eb1e0", null ],
    [ "GetTurnServerCredential", "d2/d45/class_accel_byte_1_1_api_1_1_turn_manager.html#a849cee80a2f891cbbfc666c7e602cedb", null ],
    [ "GetTurnServers", "d2/d45/class_accel_byte_1_1_api_1_1_turn_manager.html#a8f4a4bf6d7529cff5a873aecd4220a6b", null ],
    [ "SendMetric", "d2/d45/class_accel_byte_1_1_api_1_1_turn_manager.html#a5798512f8eb935433bd255e3121e9193", null ]
];