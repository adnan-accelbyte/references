var class_accel_byte_1_1_api_1_1_matchmaking_v2 =
[
    [ "CreateMatchmakingTicket", "d1/df1/class_accel_byte_1_1_api_1_1_matchmaking_v2.html#a8891950df7643bbea17410c1eaa3c263", null ],
    [ "DeleteMatchmakingTicket", "d1/df1/class_accel_byte_1_1_api_1_1_matchmaking_v2.html#a1b6d8eda9e3ec6553498103dd9be5fdf", null ],
    [ "GetMatchmakingMetrics", "d1/df1/class_accel_byte_1_1_api_1_1_matchmaking_v2.html#a579e56df4d34c69482f7160abf157ce4", null ],
    [ "GetMatchmakingTicket", "d1/df1/class_accel_byte_1_1_api_1_1_matchmaking_v2.html#a9d835eefb82a11f2936b55cbff65f96b", null ],
    [ "GetUserMatchmakingTickets", "d1/df1/class_accel_byte_1_1_api_1_1_matchmaking_v2.html#ad10d7188aee3b5af514b7abbcc47bb50", null ]
];