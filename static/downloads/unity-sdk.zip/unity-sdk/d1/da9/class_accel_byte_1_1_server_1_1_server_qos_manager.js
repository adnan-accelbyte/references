var class_accel_byte_1_1_server_1_1_server_qos_manager =
[
    [ "GetAllServerLatencies", "d1/da9/class_accel_byte_1_1_server_1_1_server_qos_manager.html#aca1c6a6a9247f1580a0444dded99c689", null ],
    [ "GetServerLatencies", "d1/da9/class_accel_byte_1_1_server_1_1_server_qos_manager.html#a1ed75106b3377baccc45af43c9cf3fc7", null ]
];