var struct_f_accel_byte_models_chat_topic_query_data =
[
    [ "Members", "d1/d07/struct_f_accel_byte_models_chat_topic_query_data.html#afc0548933b901ba149672fef277a1f82", null ],
    [ "Name", "d1/d07/struct_f_accel_byte_models_chat_topic_query_data.html#ae3c8044ddea1849990c437a7eef4dd50", null ],
    [ "Type", "d1/d07/struct_f_accel_byte_models_chat_topic_query_data.html#ab6f1557e7728f400ed40779daae4a4a3", null ],
    [ "UnreadChats", "d1/d07/struct_f_accel_byte_models_chat_topic_query_data.html#a250e3b0a844677a1cbf2cb0f64dfa80c", null ],
    [ "UpdatedAt", "d1/d07/struct_f_accel_byte_models_chat_topic_query_data.html#a3f3fd60a21b315cb64eba52e5851eac8", null ]
];