var struct_f_accel_byte_models_chat_query_chat_response =
[
    [ "Data", "d1/d96/struct_f_accel_byte_models_chat_query_chat_response.html#ae1c5194abdd66cafeddb02cde2c1c9c6", null ],
    [ "Processed", "d1/d96/struct_f_accel_byte_models_chat_query_chat_response.html#a835098bc3012237ff737b88fce6ef15f", null ]
];