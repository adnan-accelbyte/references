var struct_f_accel_byte_models_chat_public_topic_query_data =
[
    [ "Name", "d1/d64/struct_f_accel_byte_models_chat_public_topic_query_data.html#ac1255ec3d35e7649705aaba7a044fb8d", null ],
    [ "NumberOfMembers", "d1/d64/struct_f_accel_byte_models_chat_public_topic_query_data.html#a36589f907460e93c72a3eefb8b9fc548", null ],
    [ "TopicId", "d1/d64/struct_f_accel_byte_models_chat_public_topic_query_data.html#a791e72fc11c9c8428e08641926056b25", null ]
];