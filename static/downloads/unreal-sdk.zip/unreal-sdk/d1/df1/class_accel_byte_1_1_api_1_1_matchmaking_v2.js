var class_accel_byte_1_1_api_1_1_matchmaking_v2 =
[
    [ "CreateMatchTicket", "d1/df1/class_accel_byte_1_1_api_1_1_matchmaking_v2.html#ab98cff4fcbf7880b2743e2ace83b5664", null ],
    [ "CreateMatchTicket", "d1/df1/class_accel_byte_1_1_api_1_1_matchmaking_v2.html#ae9086c45782da25bcc2f5993229027f2", null ],
    [ "DeleteMatchTicket", "d1/df1/class_accel_byte_1_1_api_1_1_matchmaking_v2.html#ab738e83494eee24a1557518ba0ae8f32", null ],
    [ "GetMatchmakingMetrics", "d1/df1/class_accel_byte_1_1_api_1_1_matchmaking_v2.html#aac012aa743d004d85eacf8e18960ea65", null ],
    [ "GetMatchTicketDetails", "d1/df1/class_accel_byte_1_1_api_1_1_matchmaking_v2.html#ac92abfe3fe3de5114f001b56d53709b6", null ],
    [ "GetMyMatchTickets", "d1/df1/class_accel_byte_1_1_api_1_1_matchmaking_v2.html#adb4603a9e3b7d2b16187a44bf92128a6", null ]
];