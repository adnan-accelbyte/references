var struct_f_accel_byte_models_paginated_user_achievement =
[
    [ "CountInfo", "d0/da5/struct_f_accel_byte_models_paginated_user_achievement.html#a8dc8852a0ee53dde5641afc57316a19f", null ],
    [ "Data", "d0/da5/struct_f_accel_byte_models_paginated_user_achievement.html#a1103994b8b025dbf95d174903dda0324", null ],
    [ "Paging", "d0/da5/struct_f_accel_byte_models_paginated_user_achievement.html#a78dbcb4e93b55bcafff36b126d6b36e1", null ]
];