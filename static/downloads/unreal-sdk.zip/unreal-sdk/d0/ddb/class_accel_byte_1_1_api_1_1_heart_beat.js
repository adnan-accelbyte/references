var class_accel_byte_1_1_api_1_1_heart_beat =
[
    [ "SetHeartBeatEnabled", "d0/ddb/class_accel_byte_1_1_api_1_1_heart_beat.html#abc8b1cce2cb41f398b42320468a81cfc", null ],
    [ "SetHeartBeatResponseDelegate", "d0/ddb/class_accel_byte_1_1_api_1_1_heart_beat.html#afb24606008fbf3cc43a5c7b085b2854d", null ],
    [ "Shutdown", "d0/ddb/class_accel_byte_1_1_api_1_1_heart_beat.html#adb8b52c99cfde099b5b8e06f56c630c3", null ],
    [ "Startup", "d0/ddb/class_accel_byte_1_1_api_1_1_heart_beat.html#ad600f91dfe2681ca1bccb4389bad1bd4", null ]
];