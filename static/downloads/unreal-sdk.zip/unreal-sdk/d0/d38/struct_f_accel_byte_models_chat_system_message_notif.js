var struct_f_accel_byte_models_chat_system_message_notif =
[
    [ "GetSystemMessageData", "d0/d38/struct_f_accel_byte_models_chat_system_message_notif.html#a187b0c8a8e830cd16b8c251f7d1e9ce5", null ],
    [ "IsTransientSystemMessage", "d0/d38/struct_f_accel_byte_models_chat_system_message_notif.html#a1cec9f2f5162d734bf610c53f6970127", null ]
];