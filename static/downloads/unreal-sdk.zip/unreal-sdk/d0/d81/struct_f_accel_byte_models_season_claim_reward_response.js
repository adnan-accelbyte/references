var struct_f_accel_byte_models_season_claim_reward_response =
[
    [ "ClaimingRewards", "d0/d81/struct_f_accel_byte_models_season_claim_reward_response.html#a4e4658142f89a9796fa317dee9e63fd8", null ],
    [ "ToClaimRewards", "d0/d81/struct_f_accel_byte_models_season_claim_reward_response.html#a6282813e4933de6890d923f0ee1b4e33", null ]
];