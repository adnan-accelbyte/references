var struct_f_accel_byte_models_update_group_request =
[
    [ "GroupDescription", "d2/d2b/struct_f_accel_byte_models_update_group_request.html#a59d7b9a2499e7717a21520852969bbb0", null ],
    [ "GroupIcon", "d2/d2b/struct_f_accel_byte_models_update_group_request.html#ad5ac07c956bb079020d0778da2cb1c8e", null ]
];