var class_accel_byte_1_1_api_1_1_turn_manager =
[
    [ "GetClosestTurnServer", "d2/d45/class_accel_byte_1_1_api_1_1_turn_manager.html#affd0e538e5bae54ed7c3f33ea6c2499b", null ],
    [ "GetTurnCredential", "d2/d45/class_accel_byte_1_1_api_1_1_turn_manager.html#a0634c40b9a3f546763e22a544ca89865", null ],
    [ "GetTurnServers", "d2/d45/class_accel_byte_1_1_api_1_1_turn_manager.html#ae1e3d9ce8414bd54c7ef53dad51a97a2", null ],
    [ "SendMetric", "d2/d45/class_accel_byte_1_1_api_1_1_turn_manager.html#a97799d58dbf57adba4c1e707470e02a9", null ]
];