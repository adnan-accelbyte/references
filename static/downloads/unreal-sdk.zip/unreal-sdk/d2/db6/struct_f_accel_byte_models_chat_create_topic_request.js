var struct_f_accel_byte_models_chat_create_topic_request =
[
    [ "Admins", "d2/db6/struct_f_accel_byte_models_chat_create_topic_request.html#a282b5c3de990db11e85d26c78bbf78b3", null ],
    [ "IsJoinable", "d2/db6/struct_f_accel_byte_models_chat_create_topic_request.html#af6645bd8246bfc4856c67298f4278ab4", null ],
    [ "Members", "d2/db6/struct_f_accel_byte_models_chat_create_topic_request.html#a10b29b65b8121a1952f055a9893be0d1", null ],
    [ "Name", "d2/db6/struct_f_accel_byte_models_chat_create_topic_request.html#a33795208f403e698540f745478a28973", null ]
];