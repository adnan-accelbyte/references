var class_accel_byte_1_1_game_server_api_1_1_server_qos_manager =
[
    [ "GetActiveQosServers", "d2/d64/class_accel_byte_1_1_game_server_api_1_1_server_qos_manager.html#a462ba845084bceb7f0836f5c061ebd93", null ],
    [ "GetQosServers", "d2/d64/class_accel_byte_1_1_game_server_api_1_1_server_qos_manager.html#aff5ed5f1a2f0b50439cb3a561021c57a", null ],
    [ "GetServerLatencies", "d2/d64/class_accel_byte_1_1_game_server_api_1_1_server_qos_manager.html#a69a05e9098d2664dbf38d2e70427d423", null ]
];